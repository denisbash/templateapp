{-# LANGUAGE RecordWildCards  #-}
module Common (
   Todo(..),
   Todos(..),
   newTodo,
   addTodo,
   setStatusToDone,
   mapTodoWithKey 
  ) where

import Data.Text (Text)
import qualified Data.IntMap as IM

data Status = Editable | Done deriving Show

data Todo = Todo{todoText :: Text, todoStatus :: Status} deriving Show

type Todos = IM.IntMap Todo 

newTodo :: Text -> Todo
newTodo txt = Todo txt Editable

addTodo :: Todo -> Todos -> Todos
addTodo todo todos = IM.insert (maybe 0 (succ . fst) (IM.lookupMax todos)) todo todos

setStatusToDone :: Todo -> Todo
setStatusToDone todo = todo{todoStatus=Done}

mapTodoWithKey :: Int -> (Todo -> Todo) -> Todos -> Todos
mapTodoWithKey i f todos = IM.mapWithKey (\j t -> if j==i then f t else t) todos
